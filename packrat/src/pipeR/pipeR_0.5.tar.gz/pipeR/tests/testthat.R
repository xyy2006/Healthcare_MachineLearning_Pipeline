library(testthat)
test_check("pipeR")
