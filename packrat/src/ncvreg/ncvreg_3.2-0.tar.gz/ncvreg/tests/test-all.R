## Tests for consistency, both internal and external
## To run, you need the testthat, Matrix, and glmnet packages
## Some of these tests are interactive

## library(ncvreg)
## library(testthat)
## test_package("grpreg")
