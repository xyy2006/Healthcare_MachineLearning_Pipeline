coxCVL <- function(y, cv.ind, yhat) {
  stop("cross-validation not yet implemented for Cox models")
}
