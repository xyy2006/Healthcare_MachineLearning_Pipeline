## .First.lib <- function(lib, pkg) {
##     library.dynam("geepack", pkg, lib)
## }
