#ifndef GEESE_H
#define GEESE_H

using namespace std;
using namespace TNT;


#endif //GEESE_H
