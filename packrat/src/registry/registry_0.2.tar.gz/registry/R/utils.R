## This should be in base R!
.FUNCall <- function(f) function(...) f(...)
